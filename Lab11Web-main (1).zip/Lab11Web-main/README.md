# Lab11Web

### Membuat PHP Frame Work (Codeigniter) Lanjutan <b>

Ini merupakan tugas membuat PHP Frame Work dengan menambahkan file untuk gambar.

1. Menambahkan field input pada file views/artikel/from_add.php seperti berikut.
```
<p>
<input type="file" name="gambar">
</p>
```

2. Dan sesuaikan tag from dengan menambahkan ecrypt type seperti berikut.
```
<form action="" method="post" enctype="multipart/form-data">
```

### OUTPUT
<img src="./ss/s.png" style="margin: auto; width:800px;">

> Tampilan saat menambahkan artikel

<img src="./ss/ss.png" style="margin: auto; width:800px;">

<img src="./ss/s.png" style="margin: auto; width:800px;">

> Tampilan saat kita sudah menambahkan artikel dengan gambar.